<?php
?>
<?php include 'inc/head.php'?>

<iframe width="100%" height="680px" src="https://www.practically.com/web/pricing.php" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<?php
?>
<?php include 'inc/footer.php'?>